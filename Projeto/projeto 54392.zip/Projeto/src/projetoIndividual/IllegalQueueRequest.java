package projetoIndividual;

public class IllegalQueueRequest extends Exception {

	private static final long serialVersionUID = 7399265976541982440L;

    public IllegalQueueRequest(String msg) {
        super(msg);
    }
}
