package projetoIndividual;

import java.lang.reflect.Array;

public class ArrayQueueSystem<E> implements QueueSystem<E> {

	public Queue<E>[] queues;
	private int nQueues;       // how many queues do we have? 
	private int current;
	private int length;
	
	/**
	 * Constructor
	 * @param howManyQueues the initial number of active queues
	 */
	@SuppressWarnings("unchecked")
	public ArrayQueueSystem(int howManyQueues) {
		
		// we start with some extra space to account for new queues 
		queues  = (Queue<E>[])Array.newInstance(Queue.class, howManyQueues * 2);
		for(int i=0;i<=howManyQueues-1;i++) {
			queues[i] = new ArrayQueue<E>();
		}
		current = 0;
		nQueues = howManyQueues;
		length  = 0;
		
		//TODO
	}
	
	// TODO
	
	/* note: when creating new queues, the vector might became full. 
	 * Use the same strategy applied in classes Stack or Queue
	 * (ie, the new vector will have twice the elements) to achieve 
	 * more space.
	 */

	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		
		for(int i=0; i<nQueues; i++) {
			sb.append(queues[i]).append("\n");
		}
		
		return sb.toString();
	}
	
	public int lenght(){
		return this.queues[current].size();
	}

	@Override
	public int current() {
		return current;
	}

	@Override
	public void enqueue(E e) throws IllegalQueueRequest {
		queues[current].enqueue(e);
		
	}

	@Override
	public void dequeue() throws IllegalQueueRequest {
		queues[current].dequeue();
		
	}

	@Override
	public E front() throws IllegalQueueRequest {
		return queues[current].front();
	}

	@Override
	public boolean isEmpty() {
		return queues[current].isEmpty();
	}

	@Override
	public int howManyQueues() {
		return this.nQueues;
	}

	@Override
	public int howManyActiveQueues() {
		int counter = 0;
		for(int i=0;i<=this.howManyQueues()-1;i++) {
			if(queues[i].activeCheck()) {
				counter++;
			}
		}
		return counter;
	}

	@Override
	public int size() {
		int counter = 0;
		for(int i=howManyQueues();i>=0;i--) {
			if(this.isActivated(i)) {
			counter = counter + queues[i].size();
			}
		}
		return counter;
	}

	@Override
	public void create() {
		ArrayQueue<E> AQ = new ArrayQueue<E>(); 
		if(nQueues++>=queues.length) {
			reallocateAQS();
		}
		for(int i=howManyQueues()+1;i>=1;i--) {
			queues[i] = queues[i-1];
		}
		queues[0] = AQ;
		
	}

	@Override
	public boolean isActivated(int i) {
		if(queues[i]==null) {
			return false;
		}
		return queues[i].activeCheck();
	}

	@Override
	public void activate(int i) {
		if(this.queues[i] != null) {
			this.queues[i].activeAlt(true);	
		}
	}

	@Override
	public void deactivate(int i) throws IllegalQueueRequest {
		while(!queues[i].isEmpty()) {
			queues[i].dequeue();
		}
		queues[i].activeAlt(false);
	}

	@Override
	public void focus(int i) throws IllegalQueueRequest {
		if(isActivated(i)) {
		this.current = i;
		this.activate(current);
		}
	}

	@Override
	public int focusMin() throws IllegalQueueRequest {
		int size = this.size();
		int iValue = this.current();
		for(int i=0;i<=howManyQueues();i++) {
			if((isActivated(i)&&(queues[i].size()<=size))) {
				size = queues[i].size();
				iValue = i;
			}
		}
		this.current = iValue;
		this.activate(current);
		return size;
	}

	@Override
	public int focusMax() throws IllegalQueueRequest {
		int size =0;
		int iValue = 0;
		for(int i=0;i<=howManyQueues()-1;i++) {
			if((queues[i].size()>size)&&(isActivated(i))) {
				size = queues[i].size();
				iValue = i;
			}
		}
		this.current = iValue;
		this.activate(current);
		return size;
	}

	private void reallocateAQS() {
		Queue<E>[]newQueues  = (Queue<E>[])Array.newInstance(Queue.class, howManyQueues() * 2);
		System.arraycopy(queues, current, newQueues, 0, length);
		//copy size-head elements from position head  of array q
		//to positions 0 to 0+size-head of array newQ
		System.arraycopy(queues, 0, newQueues, length, current); 
		nQueues= newQueues.length-1;
		queues = newQueues;
	}
}